package android.suryadevs.com.firebasefamilylist;

/**
 * Created by Harshal Suryawanshi on 10-02-2016.
 */
public class RowContent {
    public String imageURL;
    public String name;
    public String relation;

    public RowContent(String imageURL, String name, String relation) {
        this.imageURL = imageURL;
        this.name = name;
        this.relation = relation;
    }

}
