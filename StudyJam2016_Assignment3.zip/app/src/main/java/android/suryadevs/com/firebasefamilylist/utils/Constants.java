package android.suryadevs.com.firebasefamilylist.utils;

import android.suryadevs.com.firebasefamilylist.BuildConfig;

/**
 * Created by Harshal Suryawanshi on 17-02-2016.
 */
public class Constants {

    public static final String FIREBASE_URL = BuildConfig.UNIQUE_FIREBASE_ROOT_URL;
    //In case the above line doesnt work:
    //Firebase URL is: https://familylist-suryadevs.firebaseio.com/
}
